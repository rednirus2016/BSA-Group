@extends('layouts.app')
@section('meta_title',$category->meta_title)
@section('meta_keywords',$category->meta_keyword)
@section('meta_description',$category->meta_description)
@section('meta_image')
    @if($category->image)
        content="{{ Request::root() }}/storage/{{$category->image}}"
    @else
        content="{{ Request::root() }}/images/logo-2.png"
    @endif
@endsection
@section('content')

<section class="page-title-layout1 page-title-light pb-0 bg-overlay bg-parallax">
      <div class="bg-img"><img src="/assets/images/bg-pcd.jpg" alt="background"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
            <h1 class="pagetitle-heading">{{$category->name}}</h1>
           
            
          </div>
        </div>
      </div>
      <div class="breadcrumb-area">
        <div class="container">
          <nav>
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item">
                <a href="/"><i class="icon-home"></i> <span>Home</span></a>
              </li>
             
              <li class="breadcrumb-item active" aria-current="page">{{$category->name}}</li>
            </ol>
          </nav>
        </div>
      </div>
    </section>
    <section class=" pb-80">
      <div class="container">
        <div class="row">
          

          <div class="col-sm-12 col-md-12 col-lg-8">
             <div class="table-responsives">
                            <table class="table table-responsive table-bordered table-striped table-hover datatable datatable-User myTable">
                                <thead>
                                    <tr>
                                       
                                        
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Composition</th>
                                         
                                        <th>Packing Size</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     @foreach ($products as $item)
                                        <tr>
                                            
                                              <td>@if($item->image)
                                              <img src="/{{$item->image}}" width="100px">
                                              @else
                                              <img src="/front_asset/images/p-demo.jpg" width="100px">
                                              @endif</td>
                                            
                                            <td><a href="{{ $item->slug }}">{{ $item->name }}</a></td>
                                            <td>{{ $item->composition }}</td>
                                            <td>
                                                {{ $item->packing }}   
                                            </td>
                                            
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
          </div>
          <div class="col-sm-12 col-md-12 col-lg-4">
            <aside class="sidebar has-marign-right sticky-top mb-50">
             
              <div class="widget widget-posts">
                <h5 class="widget-title">Latest Product</h5>
                <div class="widget-content">

                @foreach($lat as $l)
                  <!-- post item #1 -->
                  <div class="widget-post-item d-flex align-items-center">
                    <div class="widget-post-img">
                      <a href="#">@if( $l->image)
                     <img alt="/{{ $l->name}}" class="xzoom" src="{{asset('')}}/{{ $l->image }}" xoriginal="{{asset('')}}/{{ $l->image }}" width="100%" >
                     @else
                     <img alt="/{{ $l->name}}" class="xzoom" src="{{asset('product-image-dummy.jpg')}}" xoriginal="{{asset('product-image-dummy.jpg')}}" width="100%" >
                     @endif</a>
                    </div><!-- /.widget-post-img -->
                    <div class="widget-post-content">
                    <span class="widget-post-date">{{$l->created_at->format('Y-m-d')}}</span>
                      <h4 class="widget-post-title"><a href="{{$l->slug}}">{{$l->name}}</a>
                      </h4>
                    </div><!-- /.widget-post-content -->
                  </div><!-- /.widget-post-item -->
                 @endforeach
                 
                </div><!-- /.widget-content -->
              </div>
              <div class="widget widget-categories">
                <h5 class="widget-title">Divisons</h5>
                <div class="widget-content">
                  <ul class="list-unstyled mb-0">
                    <li>
                      <a href="#"><span class="cat-title">Rumi Pharma</span><span class="cat-count">6</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Thea</span><span class="cat-count">8</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">NYX Critical Care</span><span class="cat-count">9</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Janus Neutrave</span><span class="cat-count">1</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Janus Gold</span><span class="cat-count">1</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Burgeon Healthcare</span><span class="cat-count">4</span></a>
                    </li>
                  
                    <li>
                      <a href="#"><span class="cat-title">Drishti Ophthalmic</span><span class="cat-count">1</span></a>
                    </li>
                  </ul>
                </div><!-- /.widget-content -->
              </div>
            </aside>
          </div>
        </div>
      </div>
    </section>








@endsection




