@extends('layouts.app')
@section('meta_title','')
@section('meta_keywords','')
@section('meta_description','')
@section('meta_image')
content="{{ Request::root() }}/images/logo-2.png"
@endsection
@section('content')


@endsection