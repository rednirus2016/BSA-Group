@extends('layouts.app')
@section('meta_title',$product->meta_title)
@section('meta_keywords',$product->meta_keyword)
@section('meta_description',$product->meta_description)
@section('meta_image')
@if($product->image)
content="{{ Request::root() }}/storage/{{$product->image}}"
@else
content="{{ Request::root() }}/images/logo-2.png"
@endif
@endsection
@section('content')
<section class="page-title-layout1 page-title-light pb-0 bg-overlay bg-parallax">
   <div class="bg-img"><img src="/assets/images/bg-pcd.jpg" alt="background"></div>
   <div class="container">
      <div class="row">
         <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
            <h1 class="pagetitle-heading">{{$product->name}}</h1>
         </div>
      </div>
   </div>
   <div class="breadcrumb-area">
      <div class="container">
         <nav>
            <ol class="breadcrumb mb-0">
               <li class="breadcrumb-item">
                  <a href="/"><i class="icon-home"></i> <span>Home</span></a>
               </li>
               <li class="breadcrumb-item active" aria-current="page">{{$product->name}}</li>
            </ol>
         </nav>
      </div>
   </div>
</section>
<br>
<div class="container">
   <div class="row justify-content-center">
      <div class="col-md-12">
         <div class="row">
            <div class="col-lg-12 col-md-12">
               <div class="row">
                  <div class="col-lg-6">
                     @if( $product->image)
                     <img alt="/{{ $product->name}}" class="xzoom" src="{{asset('')}}/{{ $product->image }}" xoriginal="{{asset('')}}/{{ $product->image }}" width="100%" >
                     @else
                     <img alt="/{{ $product->name}}" class="xzoom" src="{{asset('product-image-dummy.jpg')}}" xoriginal="{{asset('product-image-dummy.jpg')}}" width="100%" >
                     @endif
                  </div>
                  <div class="col-lg-6 product-col">
                     <h4>{{ $product->name }}</h4>
                     @if ( Session::has('flash_message') )
                     <div class="alert alert-{{ Session::get('flash_type') }} alert-dismissible fade show" role="alert">
                        <b>{{ Session::get('flash_message') }}</b>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                        </button>
                     </div>
                     @endif
                     <table class="table table-bordered">
                        <tbody>
                           <tr>
                              <td><b>Composition</b></td>
                              <td> {{ $product->composition }}</td>
                           </tr>
                           <tr>
                              <td><b>Packing</b></td>
                              <td>{{ $product->packing }}</td>
                           </tr>
                        </tbody>
                     </table>
                     <div class="accordion" id="accordion1">
                        <div class="accordion-item">
                           <div class="accordion-header" data-toggle="collapse" data-target="#collapse1">
                              <a class="accordion-title" href="#">Description</a>
                           </div>
                           <div id="collapse1" class="collapse" data-parent="#accordion1">
                              <div class="accordion-body">
                                 <p><?php
                                    echo html_entity_decode($product->description);
                                    ?></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<section class="services-layout1 services-carousel pb-0">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-12 col-md-12 col-lg-6 offset-lg-3">
            <div class="heading text-center mb-50">
               <h2 class="heading-subtitle"></h2>
               <h3 class="heading-title">Some Related Products</h3>
            </div>
         </div>
         <!-- /.col-lg-6 -->
      </div>
      <!-- /.row -->
      <div class="row">
         <div class="col-12">
            <div class="slick-carousel"
               data-slick='{"slidesToShow": 4, "slidesToScroll": 1, "autoplay": true, "arrows": true, "dots": false, "responsive": [ {"breakpoint": 1100, "settings": {"slidesToShow": 2}},{"breakpoint": 992, "settings": {"slidesToShow": 1}}, {"breakpoint": 767, "settings": {"slidesToShow": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
               @foreach ($products as $item)
               <div class="service-item">
                  <div class="service-img">
                     @if( $item->image)
                     <img alt="/{{ $item->name}}" class="xzoom" src="{{asset('')}}/{{ $item->image }}" xoriginal="{{asset('')}}/{{ $item->image }}" width="100%" >
                     @else
                     <img alt="/{{ $item->name}}" class="xzoom" src="{{asset('product-image-dummy.jpg')}}" xoriginal="{{asset('product-image-dummy.jpg')}}" width="100%" >
                     @endif
                  </div>
                  <div class="service-body min-height">
                     <div class="service-category">
                        <a href="{{$item->slug}}">{{$item->name}}</a>
                     </div>
                     <p class="service-desc">{{$item->composition}}
                     </p>
                     <a href="{{$item->slug}}" class="btn btn-link btn-primary">
                     <i class="plus-icon">+</i>
                     <span>Read More</span>
                     </a>
                  </div>
               </div>
               @endforeach
            </div>
            <!-- /.carousel -->
         </div>
         <!-- /.col-12 -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container -->
</section>
<br>
@endsection
@section('modal')
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Contact Us</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            <form action="{{ url('/enquiry/store') }}" method="post">
               @csrf
               <div class="form-group row">
                  <div class="col-md-12">
                     <input id="name" type="text" class="form-control" name="name" placeholder="Name*" required>
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-md-12">
                     <input id="enquiry" type="text" class="form-control" readonly name="enquiry" placeholder="Enquiry*" value="Enquiry about {{ $product->name }}" required>
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-md-12">
                     <input id="email" type="text" class="form-control" name="email" placeholder="Email*" required>
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-md-12">
                     <input id="phone" type="text" class="form-control" name="phone" placeholder="Phone no*" required>
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-md-12">
                     <input id="location" type="text" class="form-control" name="location" placeholder="Location*" required>
                  </div>
               </div>
               <div class="form-group row">
                  <div class="col-md-12">
                     <textarea class="form-control" name="message" placeholder="Message*" required></textarea>
                  </div>
               </div>
               <div class="form-group row mb-0">
                  <div class="col-md-6 offset-md-4">
                     <button type="submit" class="btn btn-outline-info">
                     Submit Enquiry
                     </button>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
@endsection