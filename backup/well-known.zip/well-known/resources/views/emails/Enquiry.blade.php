<table style="border-collapse: collapse; width: 100%; height: 90px;" border="">
<tbody>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>name </strong></td>
<td style="width: 50%; height: 18px; text-align: center;">{{$data["name"] }}</td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Email</strong></td>
<td style="width: 50%; height: 18px; text-align: center;">{{$data["email"] }}</td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Doctor</strong></td>
<td style="width: 50%; height: 18px; text-align: center;">{{$data["about"] }}</td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Date</strong></td>
<td style="width: 50%; height: 18px; text-align: center;">{{$data["mobile"] }}</td>
</tr>
<tr style="height: 18px;">
<td style="width: 50%; height: 18px; text-align: center;"><strong>Time</strong></td>
<td style="width: 50%; height: 18px; text-align: center;">{{$data["location"] }}</td>
</tr>

</tbody>
</table>


Thanks,<br>
{{ config('app.name') }}
