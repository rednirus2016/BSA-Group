<?php $__env->startSection('meta_title','Welcome to Best PCD Pharma Company'); ?>


<?php $__env->startSection('content'); ?>
   

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="/assets/images/JanusBiotech.png" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="/assets/images/slider2.png" alt="Second slide">
    </div>
    <!--<div class="carousel-item">-->
    <!--  <img class="d-block w-100" src="..." alt="Third slide">-->
    <!--</div>-->
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
 
   <section>
  <div class="container">
  <div class="row">
   <div class="col-12">
            <div class="slick-carousel"
              data-slick='{"slidesToShow": 6, "slidesToScroll": 1, "autoplay": true, "arrows": false, "dots": true, "responsive": [ {"breakpoint": 1100, "settings": {"slidesToShow": 2}},{"breakpoint": 992, "settings": {"slidesToShow": 1}}, {"breakpoint": 767, "settings": {"slidesToShow": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
            
              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/Soft-gel.png" alt="service">
                  <h4>Soft Gel</h4>
                </div>
              </div>
             
              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/tab.png" alt="service">
                  <h4>Tablets</h4>
                </div>
              </div>

              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/ic_tablets-capsules-1.png" alt="service">
                  <h4>Capsule</h4>
                </div>
              </div>

              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/ic_powder-granule-1.png" alt="service">
                  <h4>Protein Powder</h4>
                </div>
                
              </div>
              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/ic_sachet-1.png" alt="service">
                  <h4>Sachet</h4>
                </div>
                
              </div>
            
              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/ic_ointments-1.png" alt="service">
                  <h4>Ointments</h4>
                </div>
               
              </div>
              
               <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/2.png" alt="service">
                  <h4>Drops</h4>
                </div>
               
              </div>
              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/3.png" alt="service">
                  <h4>Injection</h4>
                </div>
               
              </div>
              <div class="service-item">
                <div class="service-img cenetr">
                  <img src="assets/images/Shots.png" alt="service">
                  <h4>Shots</h4>
                </div>
               
              </div>
            </div>
          </div>
          </div>
          </div>
        </section>


    <section class="about-layout1">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-10 col-lg-10 col-xl-6">
            
            <div class="about-img">
             
              <img src="assets/images/pcd.png" alt="about" class="w-100">
            </div>
          </div>
          <div class="col-sm-12 col-md-10 col-lg-10 col-xl-6">
            <div class="about-Texts">
            <div class="heading-layout2">
              <h2 class="heading-subtitle color-body">About Us
              </h2>
              <h3 class="heading-title mb-50">Welcome To Janus Biotech, the Best Pharma Franchise Company in India</h3>
            </div>
              <p class="mb-30">Janus Biotech is the Best PCD Pharma Franchise Company, we are known as the leading manufacturer and supplier of the best pharma products. We have our own WHO-GMP, GLP-certified manufacturing unit in Kala Amb (Himachal Pradesh).  Janus Biotech is dealing in more than 1200+ products. 1000+ happy clients connected with the Best PCD Pharma Franchise Company. Range of products in which Janus Biotech deals are the General range, Cardiac & Diabetic range, Derma range, Ophthalmic range, Critical care range, and Ayurvedic range. The tremendous growth rate that Janus Biotech experienced in the previous years indicates our strong market position.
Janus Biotech professional team includes medical specialists, R&D professionals, quality controllers, and marketing and sales executives who assist our clients in achieving their goals.
</b>.
              </p>
              
              <div class="d-flex flex-wrap align-items-center mb-30">
                
               
              </div>
              <ul class="features-list list-unstyled mb-0">
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">100% Efficacy Pharma Products</h4>
                </li>
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">PAN India-level business opportunities</h4>
                </li>
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">1200+ DCGI Approved Products</h4>
                </li>
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">1000+ Happy Clients</h4>
                </li>
                <li class="feature-item">
                  <i class="feature-icon"></i>
                  <h4 class="feature-title mb-0">On-time Delivery of Products </h4>
                </li>
              
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="services-layout1 services-carousel pb-0">
    <div class="bg-img"><img src="assets/images/bg-2.jpg" alt="banner"></div>
      <div class="container-fluid">
        <div class="row">
         <div class="col-lg-6">
             <div class="events">
                <h4>Best Quality products</h4>  
                <p>All our pharmaceutical products are the best in quality. As we are the best Third Party Pharma Manufacturers, we use superior quality raw materials for manufacturing our products.</p>
                <h4>Excellence</h4>
<p>Janus Biotech ensures pharma products that are best in efficiency, quality, and safety.</p>
<h4>Why Choose Janus Biotech</h4>

                <ul>
                    <li>WHO-GMP Certified Manufacturing Unit</li>
                    <li>1200+ Pharma Products</li>
                    <li>DCGI Approved Pharma Products</li>
                    <li>Huge Profit Margins</li>
                    <li>Attractive Promotional Tools</li>
                    <li>Affordable Prices, Marketing Rights, Widest Range</li>
                
                </ul>
             </div>
         </div>
        </div>
       
      </div>
    </section>
    <section class="banner-layout3 py-0">
      <div class="top-shape"></div>
      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-xl-6 banner-img d-flex align-items-center">
            <div class="bg-img">
              <img src="assets/images/manu.jpg" alt="backgrounds">
            </div>
           
          </div>
          <div class="col-12 col-xl-6 banner-content">
            <div class="banner-text">
              <div class="heading-layout2 heading-light">
                <h3 class="heading-title">We are provide best PCD Pharma Franchise &  third party manufacturing in India</h3>
                <p class="heading-desc mb-40">Our company is a well-known pharma Contract Manufacturer &Supplier in India for pharmaceuticals drugs. We cover different market segments like tablets, capsules, liquid, dry syrup ,sachet powders, ointments etc.
                </p>
              </div>
              <div class="fancybox-layout2 fancybox-light">
                <div class="fancybox-item">
                  <div class="fancybox-icon">
                    <i class="icon-chemistry"></i>
                  </div><!-- /.fancybox-icon -->
                  <div class="fancybox-body">
                    <h4 class="fancybox-title">OUR QUALITY APPROACH</h4>
                    <p class="fancybox-desc">This is undoubtedly the best way to get the access to external skilled professionals for best molecules</p>
                  </div><!-- /.fancybox-body -->
                </div><!-- /.fancybox-item -->
                <div class="fancybox-item">
                  <div class="fancybox-icon">
                    <i class="icon-drug"></i>
                  </div><!-- /.fancybox-icon -->
                  <div class="fancybox-body">
                    <h4 class="fancybox-title">DEDICATED WORKFORCE</h4>
                    <p class="fancybox-desc">Can now get the medicines in the new category which is not manufactured in your unit.</p>
                  </div><!-- /.fancybox-body -->
                </div><!-- /.fancybox-item -->
              </div><!-- /.fancybox-layout2 -->
              
            </div><!-- /.banner-text -->
          </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </section><!-- /.Banner Layout3 -->

    
   
   


    <section class="contact-layout4  bg-overlay-primary-gradient">
      
      <div class="container-fluid">
        <div class="row">

          <div class="col-lg-12">
            <div class="produ">
               <h4>Some Of our Product images</h4>
            </div>
            </div>
        <div class="col-12">
            <div class="slick-carousel"
              data-slick='{"slidesToShow": 5, "slidesToScroll": 1, "autoplay": true, "arrows": true, "dots": true, "responsive": [ {"breakpoint": 1100, "settings": {"slidesToShow": 2}},{"breakpoint": 992, "settings": {"slidesToShow": 1}}, {"breakpoint": 767, "settings": {"slidesToShow": 1}}, {"breakpoint": 480, "settings": {"slidesToShow": 1}}]}'>
            
              <div class="service-item">
                <div class="service-img">
                  <img src="assets/images/P-1.jpeg" alt="service">
                </div>
              </div>
             
              <div class="service-item">
                <div class="service-img">
                  <img src="assets/images/P-2.jpeg" alt="service">
                </div>
              </div>

              <div class="service-item">
                <div class="service-img">
                  <img src="assets/images/P-3.jpeg" alt="service">
                </div>
              </div>

              
              <div class="service-item">
                <div class="service-img">
                  <img src="assets/images/P-5.jpeg" alt="service">
                </div>
                
              </div>
            
              <div class="service-item">
                <div class="service-img">
                  <img src="assets/images/P-6.jpeg" alt="service">
                </div>
               
              </div>
              <div class="service-item">
                <div class="service-img">
                  <img src="assets/images/P-7.jpeg" alt="service">
                </div>
               
              </div>
               
             
            </div>
          </div>
        </div>
      </div>
    </section>

    <div class="bg-pink">
     
      <section class="banner-layout7 py-0">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-4 order-2-md">
              <div class="banner-img"><img src="assets/images/7.jpg" class="w-100" alt="banner"></div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-8 order-1-md">
              <div class="banner-content">
                <div class="heading-layout2 mb-50">
                  <h2 class="heading-title">Why People Love Us!</h2>
                </div>
                <div class="testimonials-layout3">
                  <div class="testimonials-container">
                    <div class="slider-has-navs">
                     
                      <div class="testimonial-item">
                        <h3 class="testimonial-title">Best PCD pharma company also working on third party manufacturing all the services are good very supportive staff thank uh for your service good luck.
                        </h3>
                      </div>
                      <div class="testimonial-item">
                        <h3 class="testimonial-title">
                        Go for it they are selling Janus products as per their name ..highly recommend & Manisha Bhandari ma'am is so co- operative  & working staff.
                        </h3>
                      </div>
                    </div>
                    <div class="slider-nav-thumbnails">
                      <div class="testimonial-meta d-flex align-items-center">
                        <div class="testimonial-thmb">
                          <img src="assets/images/USER.png" alt="thumb">
                        </div>
                        <div>
                          <h4 class="testimonial-meta-title">Sneha Rani</h4>
                          <p class="testimonial-meta-desc">Customer</p>
                        </div>
                      </div>
                      <div class="testimonial-meta d-flex align-items-center">
                        <div class="testimonial-thmb">
                          <img src="assets/images/USER.png" alt="thumb">
                        </div>
                        <div>
                          <h4 class="testimonial-meta-title">Neeraj Naagar</h4>
                          <p class="testimonial-meta-desc">Customer</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
			
			
			
 <div class="footer-form"> <span class="heading-look" id="mini_contact_form_container"> New Product</span> <div class="fo-form" id="mini_contact_form" style="display: none;"> 
     
     
     
     <div class="widget-content">
         <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="widget-post-item d-flex align-items-center">
                    <div class="widget-post-img">
                        <?php if($pro->image): ?>
                      <a href="#"><img alt="/CALCIBUR SYRUP" class="xzoom" src="<?php echo e($pro->image); ?>" xoriginal="https://janusbiotech.co.in/product-image-dummy.jpg" width="100%">
                      
                     </a>
                     <?php else: ?>
                     <a href="#"><img alt="/CALCIBUR SYRUP" class="xzoom" src="https://janusbiotech.co.in/product-image-dummy.jpg" xoriginal="https://janusbiotech.co.in/product-image-dummy.jpg" width="100%">
                      
                     </a>
                     <?php endif; ?>
                    </div>
                    <div class="widget-post-content">
                    <span class="widget-post-date"><?php echo e($pro->created_at->format('m/d/Y')); ?></span>
                      <h4 class="widget-post-title"><a href="<?php echo e($pro->slug); ?>"><?php echo e($pro->name); ?></a>
                      </h4>
                    </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
     </div>
     
     
     
     
 </div> </div> 
    
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/janusbiotech/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>