<!doctype html>
 <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

 <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">

     <!-- CSRF Token -->
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

     <title><?php echo $__env->yieldContent('meta_title'); ?></title>
     <meta name="title" content="<?php echo $__env->yieldContent('meta_title'); ?>">
     <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords'); ?>">
     <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
     
     <meta property="og:title" content="<?php echo $__env->yieldContent('meta_title'); ?>" />
     <meta property="og:description" content="<?php echo $__env->yieldContent('meta_description'); ?>" />
     <meta property="og:url" content="<?php echo e(Request::fullUrl()); ?>" />
    
     <meta property="og:type" content="website" />
     <meta property="og:locale" content="en_GB" />

     <meta name="twitter:card" content="summary_large_image" />
     <meta name="twitter:description" content="<?php echo $__env->yieldContent('meta_description'); ?>" />
     <meta name="twitter:title" content="<?php echo $__env->yieldContent('meta_title'); ?>" />
     <link rel="icon" type="image/x-icon" href="assets/images/JANUS-BIOTECH-LOGO.jpg">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/libraries.css">
    <link rel="stylesheet" href="/assets/css/style.css">
  
 </head>

 <body>
   
 <div class="wrapper">
 <header class="header header-layout1">
      <div class="header-topbar">
        <div class="container-fluid">
          <div class="row align-items-center">
            <div class="col-12">
              <div class="d-flex align-items-center justify-content-between">
                <ul class="contact-list d-flex flex-wrap align-items-center list-unstyled mb-0">
                  
                  <li>
                    <i class="icon-phone"></i><a href="tel:+7877000013">+91-7877000013</a>
                  </li>
                  <li>
                    <i class="icon-email"></i><a href="#">info@janusbiotech.in</a>
                  </li>
                  <li>
                    <i class="icon-location"></i><a href="contact-us.html">Plot No-84 , Raipur Kalan, Chandigarh-160102</a>
                  </li>
                </ul><!-- /.contact-list -->
                <div class="d-flex">
                  <ul class="social-icons list-unstyled mb-0 mr-30">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                  </ul><!-- /.social-icons -->
                  <form class="header-topbar-search">
                    <input type="text" class="form-control" placeholder="Type Search Words">
                    <button class="header-topbar-search-btn"><i class="fa fa-search"></i></button>
                  </form>
                </div>
              </div>
            </div><!-- /.col-12 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.header-top -->
      <nav class="navbar navbar-expand-lg sticky-navbar">
        <div class="container-fluid">
          <a class="navbar-brand" href="/">
            <img src="assets/images/JANUS-BIOTECH-LOGO.jpg" class="logo-dark" alt="logo">
          </a>
          <button class="navbar-toggler" type="button">
            <span class="menu-lines"><span></span></span>
          </button>
          <div class="collapse navbar-collapse justify-content-center" id="mainNavigation">
            <ul class="navbar-nav">
              <li class="nav-item has-dropdown">
                <a href="/" data-toggle="dropdown" class=" nav-item-link active">Home</a>
                
              </li>
              <li class="nav-item has-dropdown">
                <a href="#" data-toggle="dropdown" class="dropdown-toggle nav-item-link">About Us</a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a href="/about-us" class="nav-item-link">Company Profile</a>
                  </li>
                
                  <li class="nav-item">
                    <a href="#" class="nav-item-link">Our Certification</a>
                  </li>
                  
                </ul>
              </li>
              <li class="nav-item has-dropdown">
                <a href="#" data-toggle="dropdown" class="dropdown-toggle nav-item-link">Our Services</a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a href="/pcd-pharma-franchise" class="nav-item-link">PCD Pharma Franchise</a>
                  </li>
                  <li class="nav-item">
                    <a href="/third-party-manufacturing" class="nav-item-link">Third Party Manufacturing</a>
                  </li>
                 
                  
                </ul>
              </li>
              <li class="nav-item has-dropdown">
                <a href="/" data-toggle="dropdown" class="nav-item-link">Our Products</a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a href="/tablet-janus" class="nav-item-link">Tablets</a>
                  </li>
                  <li class="nav-item">
                    <a href="/capsule-janus" class="nav-item-link">Capsule</a>
                  </li>
                  <li class="nav-item">
                    <a href="/soft-gelatin-capsule-janus" class="nav-item-link">Soft Gelatin Capsule</a>
                  </li>
                  <li class="nav-item">
                    <a href="/injectables-janus" class="nav-item-link">Injectables</a>
                  </li>
                  <li class="nav-item">
                    <a href="/syrup-janus" class="nav-item-link">Syrup</a>
                  </li>
                  <li class="nav-item">
                    <a href="/oral-drops-janus" class="nav-item-link">Oral Drops</a>
                  </li>
                  <li class="nav-item">
                    <a href="/ointments-janus" class="nav-item-link">Ointments</a>
                  </li>
                  <li class="nav-item">
                    <a href="/dental-care-janus" class="nav-item-link">Dental Care</a>
                  </li>
                  <li class="nav-item">
                    <a href="/eye-nasal-drop-janus" class="nav-item-link">Eye Nasal Drop</a>
                  </li>
                  <li class="nav-item">
                    <a href="/protein-powder-ors-sachet-antiseptic-janus" class="nav-item-link">Protein Powder Ors Sachet Antiseptic</a>
                  </li>
</ul>
              </li>
              <li class="nav-item has-dropdown has-mega-dropdown">
                <a href="#" data-toggle="dropdown" class="dropdown-toggle nav-item-link">Division</a>
                <ul class="dropdown-menu mega-dropdown-menu">
                  <li class="nav-item">
                    <div class="container">
                      <div class="row">
                        <div class="col-sm-12 col-md-2 nav-block">
                          <h2 class="nav-title">Rumi Pharma</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/tablet-rumi">Tablets</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/capsule-softgelatin-section-rumi">Capsule Softgelatin</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/syrup-rumi">Syrup</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/eye-drops-rumi">Eyedrop</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/injections-rumi">Injection</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="protein-powder-rumi">Protein Powder</a>
                            </li>
                          </ul>
                        </div><!-- /.col-md-2  -->
                        <div class="col-sm-12 col-md-2 nav-block">
                          <h2 class="nav-title">Thea</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/creams-thea">Cream</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/soaps-thea">Soap</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/lotions-shampoo-vaginal-wash-thea">Lotions/shampoo/vaginal/wash</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/haircare-thea">	Haircare</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/face-wash-thea">Face wash</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/dusting-powder-thea">Dusting Powder</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/tablets-thea">Tablets</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/glutathione-range-thea">Glutathione Range</a>
                            </li>
                          </ul>
                        </div><!-- /.col-md-2  -->
                        <div class="col-sm-12 col-md-2 nav-block">
                          <h2 class="nav-title">NYX Critical Care</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/antimicrobials-anticholinergics-nyx">Antimicrobials Anticholinergics</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/nutritional-suppliments-liver-tuners-haematinics-nrx">Nutritional Suppliments </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/steroids-nrx">Steroids</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/cns-acting-agents-sr-nrx">Cns Acting Agents Sr</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/analgesic-anti-inflammatory-antiviral-nrx">Analgesic Anti Inflammatory Intiviral</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/antacid-anti-ulcer-anti-coagulant">Antacid Anti</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/vitamins-others-nrx">Vitamins Others</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/jelly-nrx">Jelly</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/respules-nrx">Respules</a>
                            </li>

                          </ul>
                        </div><!-- /.col-md-2  -->
                        <div class="col-sm-12 col-md-2 nav-block">
                          <h2 class="nav-title">Janus Neutrave</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/ayurvedic-nutravedic">Ayurvedic</a>
                            </li>
                            
                          </ul>
                        </div><!-- /.col-md-2  -->
                        <div class="col-sm-12 col-md-1 nav-block">
                          <h2 class="nav-title">Janus Gold</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/cardiacdiabetic-janusgold">Cardiac Diabetic</a>
                            </li>
                           
                          </ul>
                        </div><!-- /.col-md-2  -->
                        <div class="col-sm-12 col-md-1 nav-block">
                          <h2 class="nav-title">Burgeon Healthcare</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/tablet-burgeon">Tablet</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/capsule-burgeon">Capsule</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/injectable-burgeon">Injectable</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-item-link" href="/syrup-burgeon">Syrup</a>
                            </li>
                          </ul>
                        </div><!-- /.col-md-2  -->
                        <div class="col-sm-12 col-md-2 nav-block">
                          <h2 class="nav-title">Drishti Ophthalmi</h2>
                          <ul class="nav flex-column">
                            <li class="nav-item">
                              <a class="nav-item-link" href="/eye-drops-drishti">Eye Drops</a>
                            </li>
                          
                          </ul>
                        </div><!-- /.col-md-2  -->
                      </div><!--  /.row  -->
                    </div><!--  /.container  -->
                  </li><!-- /.nav-item -->
                </ul><!-- /.dropdown-menu -->
              </li><!-- /.nav-item -->
              <li class="nav-item">
                <a href="#" class="nav-item-link">Blog</a>
              </li><!-- /.nav-item -->

            </ul><!-- /.navbar-nav -->
            <ul class="header-actions d-flex align-items-center position-relative list-unstyled mb-0">
              <li class="d-none d-xl-flex align-items-center">
                <a href="/contact-us" class="btn btn-primary btn-outlined btn-contact">
                 Contact Us
                </a>
              </li>
              
            </ul>
            <button class="close-mobile-menu d-block d-lg-none"><i class="fas fa-times"></i></button>
          </div><!-- /.navbar-collapse -->
          <div class="d-none d-xl-flex align-items-center position-relative ml-30">
            <div class="contact-phone d-flex align-items-center">
              <div class="contact-icon"><i class="icon-chemical9"></i></div>
              <div>
                <span class="d-block">Call Us Now:</span>
                <a class="phone-link d-block" href="tel:7877000013">7877000013</a>
              </div>
            </div>
          </div>
        </div><!-- /.container -->
      </nav><!-- /.navabr -->
    </header>



    

     <?php echo $__env->yieldContent('content'); ?>



  
     <footer class="footer">
      <div class="footer-primary">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-3">
              <div class="footer-widget-contact">
                <h6 class="footer-widget-title">Quick Contacts</h6>
                <p>If you have any questions or need help, feel free to contact with our team.</p>
                <ul class="contact-list list-unstyled">
                  <li>
                    <a href="mailto:info@janusbiotech.in">
                      <i class="contact-icon icon-email"></i> <span>info@janusbiotech.in</span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:7877000013">
                      <i class="contact-icon icon-phone"></i> <span>7877000013</span>
                    </a>
                  </li>
                </ul>
                <p>Plot No-84, Raipur Kalan, Chandigarh-160102</p>
                <a href="/contact-us" class="btn btn-white btn-link mr-30">
                  <i class="fas fa-map-marker-alt"></i> <span>Get Directions</span>
                </a>
              </div>
            </div><!-- /.col-xl-2 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="footer-widget-nav">
                <h6 class="footer-widget-title">Quick links</h6>
                <nav>
                  <ul class="list-unstyled">
                    <li><a href="about-us.html">About Us</a></li>
                    <li><a href="team.html">PCD Pharma Franchise</a></li>
                    <li><a href="blog.html">Third Party Manufacturing</a></li>
                    <li><a href="services.html">Blog</a></li>
                    <li><a href="careers.html">Contact</a></li>
                  </ul>
                </nav>
              </div><!-- /.footer-widget-content -->
            </div><!-- /.col-lg-2 -->
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="footer-widget-nav">
                <h6 class="footer-widget-title">Divisions</h6>
                <nav>
                  <ul class="list-unstyled">
                    <li><a href="#">Rumi Pharma</a></li>
                    <li><a href="#"> Thea</a></li>
                    <li><a href="#"> NYX Critical Care</a></li>
                    <li><a href="#">Janus Neutrave </a></li>
                    <li><a href="#">Janus Gold</a></li>
                    <li><a href="#">Burgeon Healthcare</a></li>
                    <li><a href="#">Drishti Ophthalmi</a></li>
                  </ul>
                </nav>
              </div><!-- /.footer-widget-content -->
            </div><!-- /.col-lg-2 -->
            
            <div class="col-sm-6 col-md-6 col-lg-3">
              <div class="footer-widget-time">
                <h6 class="footer-widget-title">Working Hours</h6>
                <ul class="time-list list-unstyled">
                  <li>
                    <span class="day">Week Days</span><span class="time">10.00 - 6:00</span>
                  </li>
                
                  <li>
                    <span class="day">Sunday</span><span class="time">Day off</span>
                  </li>
                </ul>
                <div class="d-flex align-items-center">
                  <a href="/contact-us" class="btn btn-primary btn-block">
                    <span>Contact Us</span> <i class="icon-arrow-right"></i>
                  </a>
                </div>
              </div><!-- /.footer-widget-time -->
            </div><!-- /.col-lg-2 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.footer-primary -->
      <div class="footer-secondary">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-12 d-flex flex-wrap">
              <ul class="social-icons list-unstyled mb-0 mr-50">
                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              </ul><!-- /.social-icons -->
              <div>
                
                <div class="mt-1">
                  <span>© 2022 Janus Biotech, All Rights Reserved. Designed & Developed By</span>
                  <a class="color-secondary" href="https://rednirus.in/"><b>Rednirus Digital Media</b></a>
                </div>
              </div>
            </div><!-- /.col-lg-6 -->
          </div><!-- /.row -->
        </div><!-- /.container -->
      </div><!-- /.footer-secondary -->
    </footer>
    
    <div class="footer-social">
     
                         <ul>
                             <li class="what"><a href="https://api.whatsapp.com/send?phone=91-7877000013&amp;text=Hello Janus Biotech" data-url="https://api.whatsapp.com/send?phone=91-%7877000013&amp;text=Hello Janus Biotech" data-tab-setting="hover" data-mobile-behavior="disable" data-flyout="disable"><i class="fab fa-whatsapp" aria-hidden="true"></i>
</a></li>
                            <li class="phone"><a href="tel:7877000013"><i class="fa fa-phone"></i></a></li>
                           
                            <li class="face"><a href=""><i class="fab fa-facebook-f"></i></a></li>
                            <li class="linke"><a href=""><i class="fab fa-linkedin-in"></i></a></li>
                            <li class="insta"><a href=""><i class="fab fa-instagram"></i></a></li>
                          
                            </ul>
  </div>
    
    
   <div class="footer-socil">
        <ul>
                             <li class="what"><a href="https://api.whatsapp.com/send?phone=91-7877000013&amp;text=Hello Janus Biotech" data-url="https://api.whatsapp.com/send?phone=91-%7877000013&amp;text=Hello Janus Biotech" data-tab-setting="hover" data-mobile-behavior="disable" data-flyout="disable"><i class="fab fa-whatsapp" aria-hidden="true"></i>
                              </a></li>
                            <li class="phone"><a href="tel:7877000013"><i class="fa fa-phone"></i></a></li>
                           
                            <li class="face" data-toggle="modal" data-target="#myModal"><p>Enquiry Form</p></li>
  </div> 
    
    
  
  
  
  
   <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
 
        </div>
        <div class="modal-body">
          
          
          <form class="contact-panel-form" method="post" action="https://7oroof.com/demos/provetta/assets/php/contact.php" id="contactForm">
              <div class="row">
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name" id="contact-name" name="contact-name"
                      required>
                  </div>
                </div><!-- /.col-lg-4 -->
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" id="contact-email" name="contact-email"
                      required>
                  </div>
                </div><!-- /.col-lg-4 -->
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Phone" id="contact-Phone" name="contact-phone"
                      required>
                  </div>
                </div><!-- /.col-lg-4 -->
                <div class="col-12">
                  <div class="form-group">
                    <textarea class="form-control" placeholder="Additional Details" id="contact-message"
                      name="contact-message"></textarea>
                  </div>
                  <button type="submit" class="btn btn-secondary  btn-block btn-xhight mt-10">
                    <span>Submit Request</span> <i class="icon-arrow-right"></i>
                  </button>
                  <div class="contact-result"></div>
                </div><!-- /.col-lg-12 -->
              </div><!-- /.row -->
            </form>
          
          
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>  
    
   
  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
   <script src="/assets/js/jquery-3.5.1.min.js"></script>
  <script src="/assets/js/plugins.js"></script>
  <script src="/assets/js/main.js"></script>
 <script>
$(document).ready(function(){
  $("#mini_contact_form_container").click(function(){
    $("#mini_contact_form").slideToggle();
  });
});
</script>

 </body>

 </html><?php /**PATH /home2/janusbiotech/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>