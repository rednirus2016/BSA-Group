<?php $__env->startSection('meta_title',$category->meta_title); ?>
<?php $__env->startSection('meta_keywords',$category->meta_keyword); ?>
<?php $__env->startSection('meta_description',$category->meta_description); ?>
<?php $__env->startSection('meta_image'); ?>
    <?php if($category->image): ?>
        content="<?php echo e(Request::root()); ?>/storage/<?php echo e($category->image); ?>"
    <?php else: ?>
        content="<?php echo e(Request::root()); ?>/images/logo-2.png"
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="page-title-layout1 page-title-light pb-0 bg-overlay bg-parallax">
      <div class="bg-img"><img src="/assets/images/bg-pcd.jpg" alt="background"></div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xl-6">
            <h1 class="pagetitle-heading"><?php echo e($category->name); ?></h1>
           
            
          </div>
        </div>
      </div>
      <div class="breadcrumb-area">
        <div class="container">
          <nav>
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item">
                <a href="/"><i class="icon-home"></i> <span>Home</span></a>
              </li>
             
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
            </ol>
          </nav>
        </div>
      </div>
    </section>
    <section class=" pb-80">
      <div class="container">
        <div class="row">
          

          <div class="col-sm-12 col-md-12 col-lg-8">
             <div class="table-responsives">
                            <table class="table table-responsive table-bordered table-striped table-hover datatable datatable-User myTable">
                                <thead>
                                    <tr>
                                       
                                        
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Composition</th>
                                         
                                        <th>Packing Size</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                              <td><?php if($item->image): ?>
                                              <img src="/<?php echo e($item->image); ?>" width="100px">
                                              <?php else: ?>
                                              <img src="/front_asset/images/p-demo.jpg" width="100px">
                                              <?php endif; ?></td>
                                            
                                            <td><a href="<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></td>
                                            <td><?php echo e($item->composition); ?></td>
                                            <td>
                                                <?php echo e($item->packing); ?>   
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
          </div>
          <div class="col-sm-12 col-md-12 col-lg-4">
            <aside class="sidebar has-marign-right sticky-top mb-50">
             
              <div class="widget widget-posts">
                <h5 class="widget-title">Latest Product</h5>
                <div class="widget-content">

                <?php $__currentLoopData = $lat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <!-- post item #1 -->
                  <div class="widget-post-item d-flex align-items-center">
                    <div class="widget-post-img">
                      <a href="#"><?php if( $l->image): ?>
                     <img alt="/<?php echo e($l->name); ?>" class="xzoom" src="<?php echo e(asset('')); ?>/<?php echo e($l->image); ?>" xoriginal="<?php echo e(asset('')); ?>/<?php echo e($l->image); ?>" width="100%" >
                     <?php else: ?>
                     <img alt="/<?php echo e($l->name); ?>" class="xzoom" src="<?php echo e(asset('product-image-dummy.jpg')); ?>" xoriginal="<?php echo e(asset('product-image-dummy.jpg')); ?>" width="100%" >
                     <?php endif; ?></a>
                    </div><!-- /.widget-post-img -->
                    <div class="widget-post-content">
                    <span class="widget-post-date"><?php echo e($l->created_at->format('Y-m-d')); ?></span>
                      <h4 class="widget-post-title"><a href="<?php echo e($l->slug); ?>"><?php echo e($l->name); ?></a>
                      </h4>
                    </div><!-- /.widget-post-content -->
                  </div><!-- /.widget-post-item -->
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                </div><!-- /.widget-content -->
              </div>
              <div class="widget widget-categories">
                <h5 class="widget-title">Divisons</h5>
                <div class="widget-content">
                  <ul class="list-unstyled mb-0">
                    <li>
                      <a href="#"><span class="cat-title">Rumi Pharma</span><span class="cat-count">6</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Thea</span><span class="cat-count">8</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">NYX Critical Care</span><span class="cat-count">9</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Janus Neutrave</span><span class="cat-count">1</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Janus Gold</span><span class="cat-count">1</span></a>
                    </li>
                    <li>
                      <a href="#"><span class="cat-title">Burgeon Healthcare</span><span class="cat-count">4</span></a>
                    </li>
                  
                    <li>
                      <a href="#"><span class="cat-title">Drishti Ophthalmic</span><span class="cat-count">1</span></a>
                    </li>
                  </ul>
                </div><!-- /.widget-content -->
              </div>
            </aside>
          </div>
        </div>
      </div>
    </section>








<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/janusbiotech/public_html/resources/views/PublicPages/category.blade.php ENDPATH**/ ?>